<?php
    $state = $getState();
?>

<?php if (isset($component)) { $__componentOriginal44a508883f9207a939367952373b4021 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44a508883f9207a939367952373b4021 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.fieldset','data' => ['label' => $getLabel(),'labelHidden' => $isLabelHidden(),'attributes' => 
        \Filament\Support\prepare_inherited_attributes($attributes)
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)
    ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::fieldset'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getLabel()),'label-hidden' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isLabelHidden()),'attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(
        \Filament\Support\prepare_inherited_attributes($attributes)
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)
    )]); ?>
    <div x-data="{preview: <?php echo \Illuminate\Support\Js::from($shouldShowPreview())->toHtml() ?>}">
        <?php echo e($getChildComponentContainer()); ?>

        <!--[if BLOCK]><![endif]--><?php if($state && $state['embed_url']): ?>
            <div class="mt-6">
                <button
                    type="button"
                    x-on:click="preview = ! preview"
                    class="text-sm text-primary-500 hover:text-primary-400 focus:text-primary-400"
                >
                    <span x-show="!preview"><?php echo e(trans('matinee::matinee.show_preview')); ?></span>
                    <span x-show="preview"><?php echo e(trans('matinee::matinee.hide_preview')); ?></span>
                </button>
                <div x-cloak x-show="preview" class="fi-input-wrp mt-2 ring-1 transition duration-75 rounded-lg overflow-hidden aspect-video w-full h-auto bg-gray-300/30 ring-gray-950/10 dark:ring-white/20 dark:bg-gray-800/20">
                    <?php if (isset($component)) { $__componentOriginal5e78f94444001fbff6611d96df1b4ee0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e78f94444001fbff6611d96df1b4ee0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'matinee::components.embed','data' => ['data' => $state,'allow' => 'fullscreen; picture-in-picture','allowfullscreen' => 'true','class' => 'w-full h-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('matinee::embed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($state),'allow' => 'fullscreen; picture-in-picture','allowfullscreen' => 'true','class' => 'w-full h-full']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e78f94444001fbff6611d96df1b4ee0)): ?>
<?php $attributes = $__attributesOriginal5e78f94444001fbff6611d96df1b4ee0; ?>
<?php unset($__attributesOriginal5e78f94444001fbff6611d96df1b4ee0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e78f94444001fbff6611d96df1b4ee0)): ?>
<?php $component = $__componentOriginal5e78f94444001fbff6611d96df1b4ee0; ?>
<?php unset($__componentOriginal5e78f94444001fbff6611d96df1b4ee0); ?>
<?php endif; ?>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44a508883f9207a939367952373b4021)): ?>
<?php $attributes = $__attributesOriginal44a508883f9207a939367952373b4021; ?>
<?php unset($__attributesOriginal44a508883f9207a939367952373b4021); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44a508883f9207a939367952373b4021)): ?>
<?php $component = $__componentOriginal44a508883f9207a939367952373b4021; ?>
<?php unset($__componentOriginal44a508883f9207a939367952373b4021); ?>
<?php endif; ?>
<?php /**PATH /home/febk5472/kursus/vendor/awcodes/matinee/src/../resources/views/matinee.blade.php ENDPATH**/ ?>