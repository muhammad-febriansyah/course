<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'data' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'data' => null,
]); ?>
<?php foreach (array_filter(([
    'data' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $embedUrl = $data['embed_url'] ?? '';
    $width = (int) $data['width'] ?? 16;
    $height = (int) $data['height'] ?? 9;
    $responsive = $data['responsive'] ?? true;
?>

<!--[if BLOCK]><![endif]--><?php if($data): ?>
<div
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'responsive' => $responsive
    ]); ?>"
>
    <iframe
        src="<?php echo e($embedUrl); ?>"
        width="<?php echo e($responsive ? ($width * 10) : $width); ?>"
        height="<?php echo e($responsive ? ($height * 10) : $height); ?>"
        style="aspect-ratio:<?php echo e($width); ?>/<?php echo e($height); ?>; width: 100%; height: auto;"
        <?php echo e($attributes->except('data')); ?>

    ></iframe>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH /home/lawd5644/courseonline/vendor/awcodes/matinee/src/../resources/views/components/embed.blade.php ENDPATH**/ ?>